package shared;

import java.io.Serializable;

import exceptions.CpfException;

public class Cpf implements Serializable{

	private static final long serialVersionUID = -7647449657619232681L;
	private final String cpf;

	public Cpf(String cpf) throws CpfException {
	    cpf = cpf.replaceAll("[^\\d]", ""); // limpar pontuação
	    if (validaCpf(cpf)) {
	        this.cpf = cpf;
	    } else {
	        throw new CpfException("Cpf inválido");
	    }
	}

	public boolean validaCpf(String cpf) {
	    if (cpf.length() != 11 || cpf.matches("(\\d)\\1{10}"))
	        return false;

	    try {
	        // Cálculo do 1º dígito verificador
	        int sm = 0;
	        int peso = 10;
	        for (int i = 0; i < 9; i++) {
	            int num = cpf.charAt(i) - '0';
	            sm += num * peso--;
	        }

	        int r = 11 - (sm % 11);
	        char dig10 = (r == 10 || r == 11) ? '0' : (char) (r + '0');

	        // Cálculo do 2º dígito verificador
	        sm = 0;
	        peso = 11;
	        for (int i = 0; i < 10; i++) {
	            int num = cpf.charAt(i) - '0';
	            sm += num * peso--;
	        }

	        r = 11 - (sm % 11);
	        char dig11 = (r == 10 || r == 11) ? '0' : (char) (r + '0');

	        // Verifica se os dígitos conferem com os informados
	        return (dig10 == cpf.charAt(9)) && (dig11 == cpf.charAt(10));
	    } catch (Exception e) {
	        return false;
	    }
	}


	public String getValue() {
		return cpf;
	}
}
