package contracts;

public interface IPessoa {
	public String getNome();
	public String getEmail();
	public String getTelefone();
	public String getCadastroRF();	
}
