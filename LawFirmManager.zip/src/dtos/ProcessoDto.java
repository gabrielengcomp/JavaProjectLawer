package dtos;

import java.util.Date;

import enumarations.EFaseProcesso;

public class ProcessoDto {

	private String numero;
	private Date dataAbertura;
	private EFaseProcesso fase;
	private String tribunal;
	private String cliente;
	private String parteContraria;

	public ProcessoDto() {
	}

	public ProcessoDto(String numero, Date dataAbertura, EFaseProcesso fase, String tribunal, String cliente,
			String parteContraria) {
		cliente = cliente.replace("[^\\d]", ""); // limpar pontuação
		parteContraria = parteContraria.replaceAll("[^\\d]", ""); // limpar pontuação
		this.numero = numero;
		this.dataAbertura = dataAbertura;
		this.fase = fase;
		this.tribunal = tribunal;
		this.cliente = cliente;
		this.parteContraria = parteContraria;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public Date getDataAbertura() {
		return dataAbertura;
	}

	public void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura;
	}

	public EFaseProcesso getFase() {
		return fase;
	}

	public void setFase(EFaseProcesso fase) {
		this.fase = fase;
	}

	public String getTribunal() {
		return tribunal;
	}

	public void setTribunal(String tribunal) {
		this.tribunal = tribunal;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public String getParteContraria() {
		return parteContraria;
	}

	public void setParteContraria(String parteContraria) {
		this.parteContraria = parteContraria;
	}

}
