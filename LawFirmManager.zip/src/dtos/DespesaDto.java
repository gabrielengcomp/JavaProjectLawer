package dtos;

import java.util.Date;

public class DespesaDto {
	
	private String numProcesso;
	private Date data;
	private String descricao;
	private double valor;

	public DespesaDto() {
	}

	public DespesaDto(String numProcesso, Date data, String descricao, double valor) {
		this.numProcesso = numProcesso;
		this.data = data;
		this.descricao = descricao;
		this.valor = valor;
	}
	
	public String getNumProcesso() {
		return numProcesso;
	}

	public void setNumProcesso(String numProcesso) {
		this.numProcesso = numProcesso;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

}
