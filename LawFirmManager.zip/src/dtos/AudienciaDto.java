package dtos;

import java.util.Date;

public class AudienciaDto {
	
	private String numProcesso;
	private Date data;
	private String recomendacao;
	private String advRegistro;

	public AudienciaDto() {
	}

	public AudienciaDto(String numProcesso, Date data, String recomendacao, String advRegistro) {
		this.numProcesso = numProcesso;
		this.data = data;
		this.recomendacao = recomendacao;
		this.advRegistro = advRegistro;
	}
	
	public String getNumProcesso() {
		return numProcesso;
	}

	public void setNumProcesso(String numProcesso) {
		this.numProcesso = numProcesso;
	}


	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getRecomendacao() {
		return recomendacao;
	}

	public void setRecomendacao(String recomendacao) {
		this.recomendacao = recomendacao;
	}

	public String getRegistro() {
		return advRegistro;
	}

	public void setRegistro(String advRegistro) {
		this.advRegistro = advRegistro;
	}

}
