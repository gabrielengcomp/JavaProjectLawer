package enumarations;

public enum EFaseProcesso {
	INICIAL, INSTRUCAO, DECISAO, RECURSO
}
